body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background: #0f172a;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.container {
  background: #1e293b;
  padding: 30px;
  border-radius: 10px;
  width: 300px;
}

h2 {
  color: white;
  text-align: center;
}

input {
  width: 100%;
  padding: 10px;
  margin: 10px 0;
  border: none;
  border-radius: 5px;
}

button {
  width: 100%;
  padding: 10px;
  border: none;
  background: #2563eb;
  color: white;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background: #1d4ed8;
}

#message {
  color: white;
  text-align: center;
}